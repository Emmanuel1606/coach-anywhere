<?php
require_once("./Config.php");
class DatabaseHandler extends PDO
{
    private static $instance;

    private function DatabaseHandler()
    {
        global $host, $user, $dbname, $password;
       

        $pdoConfig = "mysql:host=$host;dbname=$dbname";
        parent::__construct($pdoConfig, $user, $password);
    }
    public static function getInstance(){
          if (!isset(self::$instance)) {
            self::$instance = new DatabaseHandler();
        }
        return self::$instance;
    }
    
    public static function sanitizeRequest($request)
    {
        foreach($request as $k=>$v)
        {
        if(strlen($request[$k])<1){
            unset($request[$k]);
        } else {
           $request[$k]= htmlentities(urldecode($v));     

        }    
        }   
        
    }
    
     public static function getEveryInstance($class)
    {   
         $result;
        try{ 
        $queryString="SELECT * FROM $class"; 
        $statement = self::$instance->prepare($queryString); 
        $statement->execute();

        $result =  $statement->fetchAll(PDO::FETCH_CLASS, $class);  
        } catch(PDOException $ex)
        {
            $ex.getMessage();
        }
        return $result;
    }

      public static function getEveryInstanceWithQuery($class, $queryBuilder)
    {
        $result;
        try{  
        $class = ucfirst($class);  
        $queryString="SELECT * FROM $class where ".$queryBuilder["query"]; 
        $statement = self::$instance->prepare($queryString); 
        $statement->execute($queryBuilder["dirty"]);

        $result=$statement->fetchAll(PDO::FETCH_CLASS, $class);  
         } catch(PDOException $ex)
        {
            $ex.getMessage();
        }
        return $result;
        
    }
   
      public static function getEveryInstanceWithSafeQuery($class, $query)
    {
        $result;
        $class = ucfirst($class);  
        $queryString="SELECT * FROM $class ".$query; 
        try{  
        
        $statement = self::$instance->query($queryString); 
        $statement->execute();

        $result=$statement->fetchAll(PDO::FETCH_CLASS, $class);  
         } catch(PDOException $ex)
        {
            $ex.getMessage();
        }
        return $result;
        
    }
 
    
    public static function getVehicle($id)
    {  
        $result;
        try{
        $queryString=QueryBuilder::buildVehicleQueryBase()." WHERE ID = ?"; 
        $statement = self::$instance->prepare($queryString); 
        $statement->execute([$id]);

        $result= $statement->fetch(PDO::FETCH_CLASS, ucfirst("vehicle"));  
          } catch(PDOException $ex)
        {
            $ex.getMessage();
        }
        return $result;
    }
    public static function getVehicles()
    {
        $result;
        try{
        $queryString=QueryBuilder::buildVehicleQueryBase(); 
        //echo $queryString;
        $statement = self::$instance->query($queryString); 
        $statement->execute();

        $result = $statement->fetchAll(PDO::FETCH_CLASS, ucfirst("vehicle"));  
        } catch(PDOException $ex)
        {
            $ex.getMessage();
        }
        return $result;

    }
    public static function getVehiclesByQuery($query)
    {
        $result;
        try{

        $queryString=QueryBuilder::buildVehicleQueryBase()." ".$query["query"]; 
        
        $statement = self::$instance->prepare($queryString);
        foreach($query["dirty"] as $k=>$v)
            {
            $statement->bindParam($k, $v[0], $v[1]);
            
            }
        $statement->execute();
       // echo $statement->queryString;
       
      
        
//        //without prepare
//          $queryString=QueryBuilder::buildVehicleQueryBase()." ".$query["query"]; 
//        
//        $statement = self::$instance->query($queryString);
//        $statement->execute();

//        $statement->execute($query["dirty"]);
        //echo $statement->queryString;
        //var_dump($query);
        $result = $statement->fetchAll(PDO::FETCH_CLASS, ucfirst("vehicle")); 
        } catch(PDOException $ex)
        {
            $ex.getMessage();
            
        }
        return $result;
        

    }    
    public static function guestInsert()
    {
        $sqlString = "INSERT INTO User(ID, position) VALUES (null, 4)";
        $statement =SELF::$instance->query($sqlString);
        if(!$statement->execute()) throw new PDOException("Inserting a new guest into the user table was unsuccesful");
                return SELF::$instance->lastInsertId();
      
    }

        public function getInstanceByID($class, $id)
    {
     //this function fetches one instance of a class based on id   
        $result;
        try{
            $class = htmlentities($id); 
            $queryString="SELECT * FROM $class where ID= ?"; 
            $statement = self::$instance->prepare($queryString); 
            $statement->execute([$id]);
            $result = $statement->fetch(PDO::FETCH_CLASS, $class);  
        }  catch(PDOException $ex)
        {
            $ex.getMessage();
            
        }
        return $result;
        

    }

    public static function getInstanceByField($class, $field, $value)
    {
     //is it gonna be safe like this? 
        $result;
        try{
            $queryString="SELECT * FROM $class where $field= ?"; 
            $statement = self::$instance->prepare($queryString); 
            $statement->execute([$value]);
            $result =  $statement->fetch(PDO::FETCH_CLASS, ucfirst($class));  
        }  catch(PDOException $ex)
        {
            $ex.getMessage();
            
        }
        return $result;
           
    }
    public static function getInstanceByFieldAll($class, $field, $value)
    {
     //is it gonna be safe like this? 
            $result;
            try{
            $queryString="SELECT * FROM $class where $field= ?"; 
            $statement = self::$instance->prepare($queryString); 
            $statement->execute([$value]);
            $result = $statement->fetchAll(PDO::FETCH_CLASS, ucfirst($class));  
            }  catch(PDOException $ex)
            {
                $ex.getMessage();

            }
            return $result;

    }
    public function getCustomerOrders($id)
    {
        //debug this mate!!!!
        $queryString = "SELECT Booking.*, "
                . "Model.modelName,"
                . "  Address.line1, Address.line2,"//  County.countyName as countyName,"
                . " Address.postCode, Address.isDropOffTheSame FROM "
                . " Booking LEFT JOIN Address ON Booking.ID = Address.bookingID "
               // . " LEFT JOIN County ON County.ID = Address.county "
                . " LEFT JOIN Vehicle ON Booking.vehicleID=Vehicle.ID "
                . " LEFT JOIN Model ON Vehicle.modelID = Model.ID "
                . " WHERE Booking.customerID = :customerID";
        $statement = self::$instance->prepare($queryString);
        $statement->bindParam(":customerID", intval($id), PDO::PARAM_INT);
        $statement->execute();
  
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);
        if($statement==false || $result==false)
        {
        throw new PDOException("Have no idea why it is falseee. ".$statement->queryString);
        }
        return $result;  
    }

}

?>