<?php


$host = "localhost";
$user ="k1716013";
$dbname="db_k1716013";
$password="b4data";
$BasketItemCounter = 0;

function incrementItemCounter(){
    global $BasketItemCounter;
    $BasketItemCounter++;
    return $BasketItemCounter;
}

?>