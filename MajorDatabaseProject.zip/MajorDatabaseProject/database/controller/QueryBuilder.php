<?php

class QueryBuilder
{
private static $instance;
private function QueryBuilder(){}
public static function getInstance()
        {
            if(!isset(self::$instance)){
                self::$instance = new QueryBuilder();
            }
            return self::$instance;
    
        }
//$allowedFields = ["model", "make", "startDate", "endDate", "numberOfSeats", "priceMin", "priceMax", "drivingLicenceType", "color" ];
public static function buildVehicleQueryBase()
{
 
    $query = "SELECT Vehicle.ID as ID, Vehicle.registrationNumber as registrationNumber, Vehicle.dateOfRegistration as dateOfRegistration, ";
    $query.= " Vehicle.colour as colour, Vehicle.modelID as modelID, Model.img as img, ";
    $query.= " Model.modelName as modelName, Model.numberOfSeats as numberOfSeats, Model.transmissionType as transmissionType,";
    $query.= " Model.makeID as makeID, Make.makeName as makeName, ";
    $query.= " Model.hourlyRateID as hourlyRateID, hourlyRate.ratePerHour as ratePerHour, ";
    $query.= " Model.licenseTypeID as licenseTypeID, licenseType.licenseTypeName as licenseTypeName ";
    $query.= " FROM Vehicle ";
    $query.= " LEFT JOIN Model ON Vehicle.modelID=Model.ID ";
    $query.= " LEFT JOIN hourlyRate  ON Model.hourlyRateID = hourlyRate.ID ";
    $query.= " LEFT JOIN licenseType ON Model.licenseTypeID =  licenseType.ID ";
    $query.= " LEFT JOIN Make ON Model.makeID =  Make.ID ";
    return $query;
}
public static function buildVehicleQ($request)
{
    
   //error handling should be done here later on!!!
    $queryString=" WHERE 1=1 ";
    $dirtyArray=[];
        if(isset($request["ID"]))
        {
            
            $queryString.="AND Vehicle.ID = :ID";
            
            $dirtyArray[":ID"] = [$request["ID"], PDO::PARAM_INT];
           
        }

        if(isset($request["model"])&& $request["model"]>0)
        {
            $queryString.="AND Vehicle.modelID  = :model";
            $dirtyArray[":model"] = [$request["model"], PDO::PARAM_INT];
        }

        if(isset($request["make"]) && $request["make"]>0)
        {
            $queryString.=" AND Vehicle.modelID in (Select ID from Model where makeID = :make)";
            $dirtyArray[":make"] = [$request["make"], PDO::PARAM_INT];
        }
    
        if(isset($request["numberOfSeats"]) && $request["numberOfSeats"]>0)
        {
        
            $queryString.=" AND Vehicle.modelID IN (SELECT ID from Model WHERE numberOfSeats >= :numberOfSeats)";
            $dirtyArray[":numberOfSeats"] = [$request["numberOfSeats"], PDO::PARAM_INT];
        
        }
        if(isset($request["priceMin"])  && $request["priceMin"]>0)
        {
            $queryString.=" AND  hourlyRateID in (SELECT ID from hourlyRate where ratePerHour> :priceMin)";
            $dirtyArray[":priceMin"] = [$request["priceMin"], PDO::PARAM_INT];
        }
        if(isset($request["priceMax"]) && $request["priceMax"]>0)
        {
            $queryString.=" AND  hourlyRateID in (SELECT ID from hourlyRate where ratePerHour< :priceMax)";
            $dirtyArray[":priceMax"] = [$request["priceMax"], PDO::PARAM_INT];
        }

        if(isset($request["licenseType"]) && $request["licenseType"]>0)
        {
            $queryString.=" AND  Vehicle.modelID  in (SELECT ID from Model WHERE licenseTypeID = :licenceType)";
            $dirtyArray[":licenceType"] = [$request["licenseType"], PDO::PARAM_INT];
        }
        if(isset($request["color"]))
        {
            $queryString.=" AND  Vehicle.colour = :color";
            $dirtyArray[":color"] = [$request["colour"], PDO::PARAM_STR];
        }
        //here I don't have a db yet
        if(isset($request["startDate"]) && strlen($request["startDate"])>0 && isset($request["endDate"])&& strlen($request["endDate"])>0)
        {
            $startDateTime = urldecode($request["startDate"]." ".$request["startDateTime"]);
            $endDateTime = urldecode($request["endDate"]." ".$request["endDateTime"]);
            
           
            //this version works if it is not prepared...
//            $queryString.=" AND "
//                  
//                    . "Vehicle.ID NOT IN(SELECT Booking.vehicleID FROM Booking WHERE Booking.startDateRequired  <= '$startDateTime' AND Booking.endDateRequired  >= '$startDateTime'"
//                    . ") "
//                    . "AND "
//                    . "Vehicle.ID NOT IN(SELECT Booking.vehicleID FROM Booking WHERE Booking.startDateRequired  <= '$endDateTime' AND Booking.endDateRequired  >= '$endDateTime'"
//                    . ")"
//                    . "AND "
//                    . "Vehicle.ID NOT IN(SELECT Booking.vehicleID FROM Booking WHERE Booking.startDateRequired  >= '$startDateTime' AND Booking.endDateRequired  <= '$endDateTime'"
//                    . ")";
//               
            
            
            
           
//          //  This is for pdo prepare
            $queryString.=" AND "
                  
                    . "Vehicle.ID NOT IN(SELECT Booking.vehicleID FROM Booking WHERE Booking.startDateRequired  <= :startDate AND Booking.endDateRequired  >= :startDate"
                    . ") "
                    . "AND "
                    . "Vehicle.ID NOT IN(SELECT Booking.vehicleID FROM Booking WHERE Booking.startDateRequired  <= :endDate AND Booking.endDateRequired  >= :endDate"
                    . ")"
                    . "AND "
                    . "Vehicle.ID NOT IN(SELECT Booking.vehicleID FROM Booking WHERE Booking.startDateRequired  >= :startDate AND Booking.endDateRequired  <=:endDate"
                    . ")";
//               
            $dirtyArray[":startDate"] = [$startDateTime, PDO::PARAM_STR];
           
            $dirtyArray[":endDate"] = [$endDateTime, PDO::PARAM_STR];
           
           
        }
       
        $returnable["query"] = $queryString;
        $returnable["dirty"] = $dirtyArray;
       // var_dump( $returnable);
        return $returnable;
    }

}

?>