<?php
require_once("../model/BasketItem.php");
require_once("../model/Basket.php");

session_start();

if(!isset($_SESSION["Basket"]))$_SESSION["Basket"]=new Basket();
if(!isset($_SESSION["BasketItemCounter"]))$_SESSION["BasketItemCounter"]=0;

if(!isset($_REQUEST["command"])) exit(0);
switch ($_REQUEST["command"]){
    case "add":

        if(!isset($_REQUEST["busID"]) || !isset($_REQUEST["busModel"]) || !isset($_REQUEST["busMake"] )
        || !isset($_REQUEST["ratePerHour"]) || !isset($_REQUEST["colour"])
        || !isset($_REQUEST["startDateTime"]) || !isset($_REQUEST["endDateTime"]) || !isset($_REQUEST['numberOfSeats'])
        || !isset($_REQUEST['driverCheck']) || !isset($_REQUEST['deliveryCheck']) || !isset($_REQUEST['address'])
        || !isset($_REQUEST['leaveCheck'])
        )                
        {
            echo "Error- incomplete query.";
            exit(0);
         }
        $busID = urldecode(htmlentities($_REQUEST["busID"]));
        $busModel = urldecode(htmlentities($_REQUEST["busModel"]));
        $busMake = urldecode(htmlentities($_REQUEST["busMake"]));
        $ratePerHour = urldecode(htmlentities($_REQUEST["ratePerHour"]));
        $colour = urldecode(htmlentities($_REQUEST["colour"]));
        $startDateTime= urldecode(htmlentities($_REQUEST["startDateTime"]));
        $endDateTime= urldecode(htmlentities($_REQUEST["endDateTime"])); 
        $numberOfSeats= urldecode(htmlentities($_REQUEST["numberOfSeats"]));   
        $driverCheck= urldecode(htmlentities($_REQUEST["driverCheck"]));   
        $deliveryCheck= urldecode(htmlentities($_REQUEST["deliveryCheck"]));   
        $address= $_REQUEST["address"];
        foreach($address as $k=>$v){
            $address[$k] = urldecode(htmlentities($v));
        }
        
        $leaveCheck= urldecode(htmlentities($_REQUEST["leaveCheck"]));   
      
//check if there is a match!
    
             
        if(!sizeof($_SESSION["Basket"]->items)==0){
            foreach($_SESSION["Basket"]->items as $v)
            {
                if($v->busID ==$busID)
                {
             
                   $currentStart =$v->startDateTime;
                   $currentEnd =$v->endDateTime;
                   $newStart = $startDateTime;
                   $newEnd =  $endDateTime;

                   if(!($newStart>$currentEnd || $newEnd<$currentStart)){
                       echo "Error- Overlapping dates for the same vehicle.";
                       exit(0);         
                   }
                }
            }
            
        } 
           
        try{
        //wrong idea - if it a previous item is deleted than the newly added bus will keep overwriting it and items won't be added but overwritten
        $itemcounter = $_SESSION["BasketItemCounter"];
        $_SESSION["BasketItemCounter"]++;
        $basketItem = new BasketItem($itemcounter, $busID, $busModel, $busMake, $ratePerHour, 
                $colour, $startDateTime, $endDateTime,  $numberOfSeats,
                $driverCheck, $deliveryCheck, $address, $leaveCheck );
        $_SESSION["Basket"]->items[$basketItem->ID] = $basketItem;
            
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
        echo "Succes- new vehicle has been added to the cart!";
        
        break;
    case "remove":
        
        try{
            $id = urldecode(htmlentities($_REQUEST["removeID"]));
            unset($_SESSION["Basket"]->items[$id]);
            echo "Success- You have removed an item from your basket.";
        } catch (Exception $ex) {
            echo "Error-"+ $ex->getMessage();
        }
        break;
    case "retrieve":
        try{
        echo json_encode($_SESSION["Basket"]);
        } catch (Exception $ex) {
            echo "Error-"+ $ex->getMessage();
        }
        break;
     case "itemNumber":
        
        echo sizeof($_SESSION["Basket"]->items);
         break;
     case "frontPageSearch":
         //error checking should come here
         if(!isset($_REQUEST["startDate"]) || !isset($_REQUEST["startDateTime"]) || !isset($_REQUEST["endDate"]) || !isset($_REQUEST["endDateTime"]))
        {
             echo "Error-Missing date parameters";
        }
       $_SESSION["frontPageSearch"]=[];
       $_SESSION["frontPageSearch"]["startDate"] = urldecode(htmlentities($_REQUEST["startDate"]));  
       $_SESSION["frontPageSearch"]["startDateTime"] = urldecode(htmlentities($_REQUEST["startDateTime"]));
       $_SESSION["frontPageSearch"]["endDate"] = urldecode(htmlentities($_REQUEST["endDate"]));
       $_SESSION["frontPageSearch"]["endDateTime"] =   urldecode(htmlentities($_REQUEST["endDateTime"]));      
       echo "Success-Proceed to the next page";
       break;
}
?>