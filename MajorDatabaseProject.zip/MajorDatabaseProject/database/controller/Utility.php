<?php

class Utility
{
  private $instance;  
  private function Utility(){}
  public function getInstance(){
      if(!isset(self::$instance)) self::$isntance = new Utility(); 
      return self::$instance;
  }  
    
}
?>