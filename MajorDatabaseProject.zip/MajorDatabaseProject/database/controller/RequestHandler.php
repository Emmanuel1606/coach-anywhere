<?php

require_once("./QueryBuilder.php");

QueryBuilder::getInstance();

require_once("./DatabaseHandler.php");
require_once("../model/ParentJSONSerialize.php");
require_once("../model/Vehicle.php");
require_once("../model/make.php");
require_once("../model/model.php");
require_once("../model/licenseType.php");
require_once("../model/County.php");
require_once("../model/Basket.php");
require_once("../model/BasketItem.php");
require_once("../model/User.php");
require_once("../model/Booking.php");

session_start();


$dbhInstance =  DatabaseHandler::getInstance();   

function sanitizeRequest($request){
    return htmlentities($request);
}

if(isset($_REQUEST["type"])){
    $output="Error";
    
switch($_REQUEST["type"])
    {
    case "vehicle":
            if(isset($_REQUEST["query"]) && $_REQUEST["query"]=="true"){
            $query = QueryBuilder::buildVehicleQ($_REQUEST);
           
            $output = DatabaseHandler::getVehiclesByQuery($query);
            } else {
              $output = DatabaseHandler::getVehicles();
            }
            
            if(isset($_REQUEST['html']))
                {
                $vehicles = $output;
                include("../view/VehicleCard.php");
                exit(0);    
                }
                
                
    break; 
    case "model":
         if(isset($_REQUEST["makeID"]) && isset($_REQUEST["query"]) && $_REQUEST["query"]=="true")
         {
             $param['dirty'][]=$_REQUEST["makeID"];
             $param['query']='makeID = ?';        
             $output =DatabaseHandler::getEveryInstanceWithQuery("Model", $param);
         }
         else 
         {
             $output =DatabaseHandler::getEveryInstance("Model");

         }
        break;
    case "make":
            $output = DatabaseHandler::getEveryInstance("Make");
    break; 
    case "licenseType":
            $output = DatabaseHandler::getEveryInstance("licenseType");
    break;
    case "county":
           $output = DatabaseHandler::getEveryInstanceWithSafeQuery("County", " ORDER BY countyName");
    break; 
    case "vehicleToTheCart":
        break;
    case "removeVehicleFromTheCart":
        break;
    case "processOrder":
        $requestAllowedFields = ["bname", "firstName", "lastName", "phoneNumber","emailAddress", "address", "address2", "county", "postcode",  "paymentMethod", "cc_name", "cc_number", "cc_expiration", "cc_cvv", "shippingSelector", "saddress1", "saddress2", "scounty", "spostcode"];
          
        try {
            $dbhInstance->beginTransaction();
            $orderHashes=[];
            $lastInsertID = $dbhInstance::guestInsert();
            
                //booking details insertion
                
                
                foreach($_SESSION["Basket"]->items as $k)
                {
                    //echo $k->startDateTime." ".$k->endDateTime."<br>";
                    $startDateTime = date("Y-m-d H:i:s", $k->startDateTime/1000);
                    $endDateTime = date("Y-m-d H:i:s", $k->endDateTime/1000);
                    $vehicleID = substr($k->busID,4);
                    $hash = hash("sha256", $k->startDateTime.$k->endDateTime.$vehicleID.$lastInsertID."chucknorris");
                    $orderHashes[] = $hash;
                    $driverRequired = ($k->driverCheck=="true")? 1: 0;
                    $deliveryCheck = ($k->deliveryCheck=="true")? 1: 0;
                    
                    $queryString="INSERT INTO Booking (ID, startDateRequired, customerID, vehicleID, endDateRequired, HashLink, driverRequired, deliveryCheck)"
                            . "VALUES(null, :startDateRequired, :customerID, :vehicleID, "
                            . ":endDateRequired, :HashLink, :driverRequired, :deliveryCheck)";
                    
                    
                    
                    $statement = $dbhInstance->prepare($queryString);
                    $statement->bindParam(":startDateRequired", $startDateTime, PDO::PARAM_STR);
                    $statement->bindParam(":endDateRequired", $endDateTime, PDO::PARAM_STR);
                    $statement->bindParam(":customerID", $lastInsertID, PDO::PARAM_INT);
                    $statement->bindParam(":vehicleID", $vehicleID, PDO::PARAM_INT);
                    $statement->bindParam(":HashLink", $hash, PDO::PARAM_STR);    
                    $statement->bindParam(":driverRequired", $driverRequired, PDO::PARAM_INT);    
                    $statement->bindParam(":deliveryCheck", $deliveryCheck, PDO::PARAM_INT);    
                    if(!$statement->execute()) {
                        echo $startDateTime." ".$endDateTime." ".$lastInsertID." ".$vehicleID." ".$hash." ".$driverRequired." ".$deliveryCheck;
                        throw new PDOException("Unsuccesful insert attemp to the Booking table.".$statement->queryString);
                    }
                    
                 
                    //address insertion should happen here
                    if($deliveryCheck==1)
                        {
                        $lastBookingInsertID=$dbhInstance->lastInsertId();
                        $queryString = "INSERT INTO Address (ID, bookingID, line1, line2, county, postcode, isDropOffTheSame)"
                                . "VALUES (null, :lastBookingInsertID, :line1, :line2, :county, :postcode, :isDropOffTheSame)";
                        $leaveCheckVar = ($k->leaveCheck == "true")? 1: 0;

                        $statement = $dbhInstance->prepare($queryString);
                        $statement->bindParam(":lastBookingInsertID", $lastBookingInsertID, PDO::PARAM_INT);
                        $statement->bindParam(":line1", $k->address["addressLine1"], PDO::PARAM_STR);
                        $statement->bindParam(":line2", $k->address["addressLine2"], PDO::PARAM_STR);
                        $statement->bindParam(":county", $k->address["county"], PDO::PARAM_INT);
                        $statement->bindParam(":postcode", $k->address["postcode"], PDO::PARAM_STR);
                        
                        $statement->bindParam(":isDropOffTheSame", $leaveCheckVar, PDO::PARAM_INT);
                        if(!$statement->execute()) throw new PDOException("Unsuccesful insert attemp to the Address table.");                        }
 
                }
                $_SESSION["lastInsertHash"] = $orderHashes[0];
               $counter = 0;
               
               foreach ($requestAllowedFields as $k)
                {
                if(!isset($_REQUEST[$k])) {
                    if($k=="shippingSelector" && !isset($_REQUEST[$k])) break;
                    throw new PDOException("The field "+ $k +" is missing, the transaction cannot be processed");   
                }
                //if($_REQUEST["shippingSelector"]!="on" || array_search( "shippingSelector", $requestAllowedFields) >$counter) break;
                 
                $_REQUEST[$k]=sanitizeRequest($_REQUEST[$k]);
                //here you should demonstrate more control and stop the process if certain vital attributes have not been provided.
                if(!strlen($_REQUEST[$k])==0){
                    $queryString = "INSERT INTO UserDetails (ID, userID, attrName, attrValue)"
                            . "VALUES (null, $lastInsertID, :attrName, :attrValue)";
                    $statement = $dbhInstance ->prepare($queryString);
                    //how about the card details???
                 
                        $statement->bindParam(":attrName", $k, PDO::PARAM_STR);
                        $statement->bindParam(":attrValue", $_REQUEST[$k], PDO::PARAM_STR);
                        if(!$statement->execute()){
                            $message="Unsuccesful insert attemp to the UserDetails table. Parameters:<br>";
                            $message.= "k: ".$k.",request[k]:". $_REQUEST[$k] ."<br> QueryString: ".$statement->queryString;
                            
                            throw new PDOException($message);                      }   
                        }
                        $counter++;
                
                }
                if($counter==0){ 
                    throw new PDOException("Something is not right when inserting the customer details...");
                    
                }
                
            if(isset($_REQUEST['emailAddress']) && sizeof($_REQUEST['emailAddress'])>0)
            {
                    
                $from = "k1721863@kingston.ac.uk";
                $to = $_REQUEST['emailAddress'];
                $subject = "Order confirmation";
                $message ="Dear customer, <br> ";
                $message .="We have processed your order(s). <br> ";
                $message.= 'To see all of your order click here:<a href="http://kunet.kingston.ac.uk/k1721863/database/view/OrderProcessed.php?all=true&hash='.$orderHashes[0].'">Click here</a><br>';        
                $counter = 1;
                 
                        $message.="<br>Kind regards, <br>";
                        $message.="Berwyn Buses Customer Team <br>";

                $headers[] = 'MIME-Version: 1.0';
                $headers[] = 'Content-type: text/html; charset=utf-8';

           // Additional headers
            $headers[] = "To:".$_REQUEST["firstName"]." ".$_REQUEST["lastName"]." <".$_REQUEST['emailAddress'].">";
            $headers[] = 'From: Berwyn buses <k1721863@kingston.ac.uk>';
            $headers[] = 'Cc: k1721863@kingston.ac.uk';
    //        $headers[] = 'Bcc: chamberhorsefeeder@gmail.com';

             if(!mail($to, $subject, $message, implode("\r\n", $headers))){
                //echo "Message has been sent to $to!";
                throw new Exception('Error while sending mail to the customer...');

             } 
           } 
        $dbhInstance->commit();
        echo "Success - The transaction has been processed";
        } catch(PDOException $pdoex)
        {
         $dbhInstance->rollBack();
         echo "Failure-".$pdoex->getMessage();
         echo "Failurecode: -".$pdoex->getCode();
         echo $pdoex;
         
        } catch (Exception $ex){
         echo "Failure-".$ex->getMessage();   
        }
        exit(0);
        break;
        
        
    case "viewOrders":
        
       
       try{
       $dbhInstance->beginTransaction();
       $cleanHash = htmlentities($_REQUEST["hash"]);
       
       $queryString = "SELECT customerID FROM Booking where HashLink= :cleanHash";
       $statement = $dbhInstance->prepare($queryString);
       $statement->bindParam(":cleanHash", $cleanHash ,PDO::PARAM_STR );
       $statement->execute();
       $result = $statement->fetch(PDO::FETCH_ASSOC);
       if($result==false)
        {
        throw new PDOException("There is no entry for the requested hash. Please get in touch with our customer service team.");

        };
        
        $customerID = $result["customerID"];
        $queryString = "SELECT attrName, attrValue from UserDetails WHERE userID =".$customerID;
        $statement = $dbhInstance->prepare($queryString);
        $statement->execute();
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);
        $user = new User();
        
        
        foreach($result as $k=>$v)
        {
            
        $user->$v["attrName"]=$v["attrValue"];
        if($v["attrName"] == "county" || $v["attrName"] == "scounty")
            {
            $attrComposed = $v["attrName"]."Name";
            $queryString = "SELECT countyName From County WHERE ID = ". $v["attrValue"] . ";";
            $statement = $dbhInstance ->prepare($queryString);
            $statement->execute();
            $result = $statement->fetch(PDO::FETCH_ASSOC);
            $user->$attrComposed= $result["countyName"];
            }
        
        }
        //this works until this. However, after this, $result will be false
       // echo "<pre>".json_encode($user)."</pre>";
        //this returns false for some reason
        $result = $dbhInstance::getCustomerOrders($customerID);
       
        foreach ($result as $k)
        {
        $user->Bookings[] = $k;
        }
            
        $dbhInstance->commit();    
        $output = $user;    
       } catch(PDOException $pdoex){
           $dbhInstance->rollback();
         echo "Failure-".$pdoex->getMessage();
         echo $pdoex;
         echo "Failurecode: -".$pdoex->getCode();
       }catch(Exception $ex){
         echo "Failure-".$ex->getMessage();
         echo "Failurecode: -".$ex->getCode();
       }
       
        break;
    
   
    }
    //switch end
   
    header("Content-type: applicaton/json");
    echo json_encode($output);
   
   
//echo "<pre>".var_dump($output)."</pre>";
}
?>