<?php
    session_start();
require_once("adminHeader.php");
    //If the user tries to bypass the email and password, it won't work.
    if(!isset($_SESSION['loggedIn']))
    {
        header('Location: index.php');
        exit();     
    }
?>
<p>Welcome admin</p>
<br>
<form id= "adminForm" method="POST">
</div>
</div>
</form>
<div class= "container">
<h1 align = "center">Admin Dashboard</h1>
</div>

