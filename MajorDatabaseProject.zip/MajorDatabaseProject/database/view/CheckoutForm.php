<?php
require_once("header.php");
    ?>
<div class="p-5" id="step-0">
    <div class="row">
        <div class="col-md-6 col-12 border-right border-primary">
             <h3> Log in </h3>
             <form>
                <label for="userName"> User Name: </label>
                <input type="text" class="form-control"> <br>
                <label for="userName"> password: </label>
                <input type="password" class="form-control mb-4"> 
                <button type="button" class="btn-primary btn-lg form-control mb-4">Login</button>

                <ul class="list-group">
                    <li class="list-group-item"><a href="">Forgotten password</a></li>
                    <li class="list-group-item"><a href="">Register an account</a></li>
                </ul>    
             </form>
        </div>
        
        <div class="col-md-6 col-12">
            <h3 class="my-4"> Check out as a guest! </h3>
            <p class ="badge-light p-4">
                No need to register, check out as fast as possible as a guest. Your order details will be available at the link sent to you by email, so no need to worry about lost details.
                
                
            </p>
            <button id="checkout-0-button" type="button" class="btn-primary btn-lg btn-block">Check out</button>
        </div>
    </div>
  
</div>

<form class="cmxform" id="checkout-form" action="./OrderProcessed.php" method="POST" novalidate="novalidate">
    <div class="p-5" id="step-1" style="display:none">
        <div class="row mt-5" id="privateBusinessSelector">
            <ul class="nav nav-pills nav-fill col-12 border border-primary">
                <li class="nav-item">
                  <a class="nav-link active privateBusinessSelector" href="#" id="privateTab">Private</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link privateBusinessSelector" href="#" id="businessTab">Business</a>
                </li>

            </ul>
        </div>
            <div class="row mt-3" id="businessCustomerForm" style="display:none">
             <div class="col-md-12 order-md-1">
               <h4 class="mb-3">Business name</h4>
               <div class="mb-3">
                  <label for="bname">Business name</label>
                  <input type="text" class="form-control" id="bname" name="bname" placeholder="You company's name">
                  
               </div>


            </div>

        </div>
        <div class="row  mt-3" id="privateCustomerForm">
            <div class="col-md-12 order-md-1">
              <h4 class="mb-3">Contact details</h4>
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label for="firstName">First name</label>
                    <input type="text" name="firstName" class="form-control" id="firstName" required>
                   
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="lastName">Last name</label>
                    <input type="text" name="lastName" class="form-control" id="lastName" required>
                   
                  </div>
                </div>
                
                <div class="mb-3">
                  <label for="phoneNumber">Phone number</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">+</span>
                    </div>
                    <input type="tel" name="phoneNumber" class="form-control" id="phoneNumber" placeholder="44749661144" required>
                   
                  </div>
                </div>
              
                <div class="mb-3">
                  <label for="emailAddress">Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">@</span>
                    </div>
                    <input type="email" name="emailAddress" class="form-control" id="emailAddress" placeholder="something@domain.co.uk" required>
                   
                  </div>
                </div>
              
              


              <h4 class="mb-3">Billing address</h4>

                <div class="mb-3">
                  <label for="address">Address</label>
                  <input type="text" class="form-control" id="address" name="address" placeholder="1234 Eden street" required>
                  
                </div>

                <div class="mb-3">
                  <label for="address2">Address 2 <span class="text-muted">(Optional)</span></label>
                  <input type="text" class="form-control" id="address2" name="address2" placeholder="Apartment or suite">
                </div>

                <div class="row">
                  
                  <div class="col-md-6 mb-3">
                    <label for="county">county</label>
                    <select class="custom-select d-block w-100 county" id="county" name="county" required>
                      <option value="0">Choose...</option>
                      <option  value="1">Surrey</option>
                    </select>
                    
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="postcode">Postcode</label>
                    <input type="text" class="form-control" id="postcode" placeholder="K123 W123" name="postcode" required>
                   
                  </div>
                </div>
                <hr class="mb-4">

            </div>
        </div>

         <div class="col-12" id="shippingAddressSelector">
            <div class="" id="shippingAddress">
                <div class="custom-control custom-checkbox">
                  <input name="shippingSelector" type="checkbox" class="custom-control-input" id="same-address" >
                  <label class="custom-control-label" for="same-address">My shipping address is different than my billing address</label>
                </div>

                <hr class="mb-4">
                    <div id="shippingAddressDetails" style="display:none">
                        <div class="mb-3">
                        <h4 class="mb-3">Shipping address</h4>

                          <label for="saddress">Address</label>
                          <input type="text" class="form-control switch_required" id="saddress" name="saddress1" placeholder="1234 Eden street" >
                          
                        </div>

                        <div class="mb-3">

                          <label for="saddress2">Address 2 <span class="text-muted">(Optional)</span></label>
                          <input type="text" class="form-control " id="saddress2" name="saddress2" placeholder="Apartment or suite">
                        </div>

                        <div class="row">
                          
                          <div class="col-md-6 mb-3">
                            <label for="scounty">County</label>
                            <select class="custom-select  w-100 switch_required county" id="scounty" name="scounty">
                              <option value="0">Choose...</option>
                              <option value="1">Surrey</option>
                            </select>
                           
                          </div>
                          <div class="col-md-6 mb-3">
                            <label for="spostcode">Postcode</label>
                            <input type="text" class="form-control switch_required" id="spostcode" name="spostcode" placeholder="K123 W123">
                          
                          </div>
                        </div>
                    </div>
            </div>
        </div>
        <div class="mb-3">
            <button id="checkout-1-button" type="submit" class=" btn-primary btn-lg">Proceed to the next step</button>

        </div>

    </div>
</form>
<form id="checkout-form2" class="cmxform" action="./OrderProcessed.php" method="POST" novalidate="novalidate">

    <div class="p-5" id="step-2" style="display:none">
          <div class="row" id="paymentDetails">
            <div class="col-md-12 order-md-1">
            <h4 class="mb-3">Payment</h4>
                <div class="d-block my-3">
                  <div class="custom-control custom-radio">
                    <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required value="0">
                    <label class="custom-control-label" for="credit">Credit card</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input id="debit" name="paymentMethod" type="radio" class="custom-control-input" required value="1">
                    <label class="custom-control-label" for="debit">Debit card</label>
                  </div>
<!--                  <div class="custom-control custom-radio">
                    <input id="paypal" name="paymentMethod" type="radio" class="custom-control-input" required value="2">
                    <label class="custom-control-label" for="paypal">PayPal</label>
                  </div>-->
                </div>
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label for="cc-name">Name on card</label>
                    <input type="text" class="form-control" id="cc-name" name="cc_name" placeholder="" required>
                    <small class="text-muted">Full name as displayed on card</small>

                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="cc-number">Credit card number</label>
                    <input type="text" class="form-control" id="cc-number" placeholder="" name="cc_number" required>

                  </div>
                </div>
                <div class="row">
                  <div class="col-md-3 mb-3">
                    <label for="cc-expiration">Expiration</label>
                    <input type="date" class="form-control" id="cc-expiration" placeholder="" name="cc_expiration" required>

                  </div>
                  <div class="col-md-3 mb-3">
                    <label for="cc-cvv">CVV</label>
                    <input type="text" class="form-control" id="cc-cvv" placeholder="" name="cc_cvv" required>

                  </div>

                </div>
            </div>
        </div>
        <div class="mb-3">
            <button id="checkout-1-button-back" type="button" class=" btn-primary btn-lg ">Go back</button>
            <button id="checkout-2-button" type="submit" class=" btn-danger btn-lg">Proceed to the next step</button>

        </div>
     
    </div>
</form> 
<div class="p-5" id="step-3" style="display:none">
    <div class="row">
        <div class="col">
            <h2> We are processing you payment! </h2>
            <div class="spinner-border text-primary" role="status">
           <span class="sr-only">Loading...</span>
            </div>
         </div>
    </div>
</div>

<?php
require_once("footer.php");
?>