<!DOCTYPE html>
 <html>

 	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width">
 		<meta name="description" content="Coach booking">
 		<meta name="keywords" content="vehicles, prices, contact">
 		<meta name="author" content="Emmanuel Pereira">
 		<title>Coach Anywhere</title>
 		<link rel="stylesheet" href="../css/style.css">
 	</head>


 	<body>
 		<header>
			<div class="container">
 				<div id="branding">
 					<h1>Vehicles</h1>
 				</div>
 				<nav>
 					<ul>
 						<li><a href="index.php">Home</a></li>
 						<li><a href="vehicles.php">Vehicles</a></li>
 						<li class="current"><a href="contact.php">Contact</a></li>
 					</ul>
 				</nav>
 			</div>
 		</header>


 		<section id="newsletter">
 			<div class="container">
 				<h1>Subscribe for Latest Notifications</h1>
 				<form>
 					<input type="email" placeholder="Enter Email">
 					<button type="submit" class="button1">Subscribe</button>
 				</form>
 			</div>
 		</section>

 					<div class="dark">
 						<h3>More Info</h3>
 						<form class="info">
 								<div>
 									<label>Name</label><br>
 									<input type="text" placeholder="Name">
 								</div>
 								<div>
 									<label>Email</label><br>
 									<input type="text" placeholder="Email Address">
 								</div>
 								<div>
 									<label>Card Number</label><br>
 									<textarea placeholder="card number"></textarea>
 								<div>
                                    <label>Expiry Date</label><br>
 									<textarea placeholder="Date"></textarea>
                                 </div>
                                

 								<button class="button1" type="submit">Send</button>
 						</form>	
 					</div>
 				</aside>		
 			</div>
 		</section>


 		<footer>
 			<p>Coach Anywhere, Copyright &copy; 2019</p>
 		</footer>
 	</body>
 </html>