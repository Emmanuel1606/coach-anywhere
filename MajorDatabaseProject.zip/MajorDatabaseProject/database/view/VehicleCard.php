<?php 
$counter=0;
$output ="<div class='row h-50'>";
foreach($vehicles as $k=>$vehicle):
//var_dump($vehicles);
 if($counter%3==0 && $counter>0):
     $output.= 
     <<<EOD
  
</div>
<div class='row h-50'>
EOD;
 endif; 
$output.=
<<<EOD
        
    <div class="col-12 col-sm-6 col-md-4 my-4 p-3  float-left" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/$vehicle->img" class="w-100 h-25" alt="$vehicle->modelName" style="object-fit:cover">
    <ul class="list-group">
  
        <li class="list-group-item"> <h5 class="mt-2" id="model_$vehicle->ID">$vehicle->modelName</h5></li>
        <li class="list-group-item"> <h6 id="make_$vehicle->ID">make: $vehicle->makeName</h6></li>
      
        <li class="list-group-item">Seats:<span id="numberOfSeats_$vehicle->ID">$vehicle->numberOfSeats</span></li>
        <li class="list-group-item">Colour:<span  id="colour_$vehicle->ID">$vehicle->colour</span></li>
        <li class="list-group-item">£/h:<span  id="ratePerHour_$vehicle->ID">$vehicle->ratePerHour</span></li>
        <li class="list-group-item">License:<span  id="licenseType_$vehicle->ID">$vehicle->licenseTypeName</span></li>

      </ul>
      <div>
       <button class="addToBasket btn btn-primary btn-lg btn-block" id="bus_$vehicle->ID"> Add to cart </button>
      </div>
    </div>

EOD;
$counter++;
endforeach;
$output.= <<<EOD
</div>
EOD;
echo $output;

