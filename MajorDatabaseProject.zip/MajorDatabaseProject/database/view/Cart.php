<?php
require_once("./header.php");
?>
<div class="col-12 m-4">
    <?php
    if(!isset($_SESSION['Basket']) || sizeof($_SESSION['Basket']->items)==0)
            {
        ?>
        <h1> Your basket is empty! </h2>
        <?php
            } 
            else {
              $B = $_SESSION['Basket'];  
                ?>
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your Basket</span>
            <span class="badge badge-secondary badge-pill" id="basketBadgeOverview">
              <?=sizeof($B->items)?>
            
            </span>
          </h4>
          <ul class="list-group mb-3 col-12" id="basketListContainer">
              <?php 
              $totalCost = 0;
              foreach($B->items as $item):
                    
                        $startDate = $item->startDateTime;
                        $formattedStartDate = date("d/m/y G:i", $startDate);
                        $endDate = $item->startDateTime;
                        $formattedEndDate = date("d/m/y G:i", $endDate);  
                        $tripTime = round(($item->endDateTime-$item->startDateTime)/1000/3600);
                        $busTotal = ($item->ratePerHour*$tripTime);
                        $totalCost+=round($busTotal);
                         $addressOutput = "";
                        if($item->deliveryCheck=="true")
                        {
                            foreach($item->address as $k=>$v)
                            {
                            if($k=="county") continue;    
                            $addressOutput.=$v." ";
                            }
                        } else 
                            {
                            $addressOutput="not specified";
                            }
              ?>
                <li class="list-group-item justify-content-between d-sm-flex flex-row" id="basketItem_<?= $item->ID?>">
                  <div class="col-md-9 col-sm-6 col-12">
                    <h6 >Model: <?= $item->busModel ?></h6>
                    <h6  id="">Make: <?= $item->busMake ?></h6>

                    <small class="badge badge-info">Date: 
               
                  <?= $formattedStartDate ?>
                        - 
                  <?= $formattedEndDate ?>
                    </small>
                    <small class="badge badge-warning">Hours:  <?= $tripTime ?></small>
                 
                    <small class="badge badge-danger">rate/hour:  £<?= $item->ratePerHour ?></small>    
                      <span class="badge badge-success">Total cost: £<span class="busTotal" id="busTotal_<?= $item->ID?>">
                      <?= round($busTotal) ?>
                          </span></span> <br>
                    <small class="badge badge-secondary">Driver required:  <?= ($item->driverCheck=="true")?"yes":"no" ?></small><br>    
                    <small class="badge badge-secondary">Delivery needed:  <?= ($item->deliveryCheck=="true")?"yes":"no" ?></small><br>    
                    <small class="badge badge-secondary">Drop-off location same:  <?= ($item->leaveCheck=="true")?"yes":"no" ?></small><br>    
                    <small class="badge badge-secondary">Delivery location:  <?= $addressOutput ?></small><br>    
                  </div> <br>
                  <div class="col-md-2 col-sm-5 col-12">
                    
                     <button type="button" class="removeBasketItem btn btn-danger ml-3" id="remove_<?= $item->ID?>">Remove</button>  

                  </div>
                </li>
            
             <?php
             endforeach;
             ?>
            <li class="list-group-item d-flex justify-content-between bg-light">
              <div class="text-success">
                <h6 class="my-0">Promo code</h6>
                <small>EXAMPLECODE</small>
              </div>
              <span class="text-success">-£5: This is just example, doesn't work yet</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (GPD)</span>
              <strong >£<span id="basketTotal"><?= round($totalCost) ?></span></strong>
            </li>
          </li>

          <form class="card p-2">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Promo code">
              <div class="input-group-append">
                <button type="submit" class="btn btn-danger">Redeem</button>
              </div>
            </div>
          </form>
        <form class="card p-2" action="CheckoutForm.php">
            <div class="input-group col-12 col-sm-12 col-md-3">
                <button type="submit" id="goToCheckoutForm" class="btn btn-primary btn-lg btn-block">Checkout</button>
            </div>
            </div>
         </form>
<?php
    }
require_once("./footer.php");
?>