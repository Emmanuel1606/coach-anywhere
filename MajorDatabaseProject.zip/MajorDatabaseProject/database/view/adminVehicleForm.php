<?php
require_once("adminHeader.php");
?>
<!doctype <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="adminjs.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
.dropbtn {
  background-color: grey;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
    display: block;
  margin-right: auto;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: darkgrey;}
</style>
</head>


<body>
<h1 class="display-4" align = "center">Add Vehicles</h1>
<form>
<form action="/action_page.php">


  <label for="make">Vehicle Make</label>
      <select id="make" name="make" class="form-control">
  
    <option value = 0 href="#">Any Make</option>
    <option value = 1 href="#">Mercedes-Benz</option>
    <option value = 2 href="#">Volvo</option>
    <option value = 3 href="#">Scania</option>
    <option value = 4 href="#">Ford</option>
    <option value = 5 href="#">Van Hool</option>
  
  </select>

<br>
<!--<p>Make<select name="cars">
  <option id="mercedes">Mercedes-Benz</option>
  <option id="volvo">Volvo</option>
  <option id="scania">Scania</option>
  <option id="ford">Ford</option>
  <option id="vanhool">Van Hool</option>
</select>
</p>!-->
</form>
  <div class="form-group">
    <label for="formGroupSeatsInput">Number of Seats</label>
    <input type="number" class="form-control" id="formGroupSeatsInput" placeholder="Seats input">
  </div>
  <div class="form-group">
    <label for="formGroupColourInput">Colour</label>
    <input type="text" class="form-control" id="formGroupColourInput" placeholder="Colour">
  </div>
  <div class="form-group">
    <label for="formGroupColourInput">Hourly Rate</label>
    <input type="number" class="form-control" id="formGroupColourInput" placeholder="Hourly Rate">
  </div>
  <div class="form-group">
   
    <label for="make">License</label>
      <select id="license" name="license" class="form-control">
      <option value = 0 href="#">Any License</option>
      <option value = 1 href="#">D1</option>
      <option value = 2 href="#">D</option>
      <option value = 3 href="#">B</option>
      <option value = 4 href="#">B auto</option>
      <option value = 5 href="#">C</option>
      </select> 
      </br>

      </div>
                        
  </div>
 <!-- <input class = "dropbtn" type="submit" value="Submit"> !-->
 <button id="addVehiclesSubmit" type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
</form>
    
</body>
</html>