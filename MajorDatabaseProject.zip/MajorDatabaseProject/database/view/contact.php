<?php require_once("header.php"); ?>

 		<section id="newsletter">
 			<div class="container">
 				<h1>Subscribe for Latest Notifications</h1>
 				<form>
 					<input type="email" placeholder="Enter Email">
 					<button type="submit" class="button1">Subscribe</button>
 				</form>
 			</div>
 		</section>


 		<section id="main">
 			<div class="container">
 				<article id="main-col">
 					<h1 class="page-title">Contact Us!</h1>
 					<p>
 					We have provided information on all our vehicles we think would be relevant for you to know prior to booking. However, in case you would like additional information on any of the service provided or vehicle, we are more than happy to help. 
 					</p>
 					
 					<p>You can contact us by email or telephone. The information has been provided below:</p>
 					<br> Contact number: 020 3456 7891
 					<br> Email: CoachAnywhereUK@hotmail.com
 					<br> 
 					<p>Alternatively you can have a look at the description of any of our vehicles to find information you may need before you go ahead with a booking. 

 					
 					
 				</article>


 				<aside id="sidebar">
 					<div class="dark">
 						<h3>How We Work</h3>
 						<p>We use our experience in sales, customer assitance and processing improvement to deal with any inquires you could possibly have regarding the latest, unreleased, best suited vehicles that are soon to be brought into the market. In addition, we like to make sure our client understands everything, so we give them the option of asking for further info when needed. We work and specialise in explaining things thoroughly to our clients. </p>
 					</div>
 				</aside>		
 			</div>
 		</section>


<?php require_once("footer.php"); ?>
