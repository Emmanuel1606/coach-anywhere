<?php
 require_once("header.php");
 ?>

<!-- Modal -->

            <form id="browseVehicle" validate>
                <div class="row">
                  <div class="col-12">
                    <h3> Trip dates </h3>
                  </div>
                   <div class="col-12 col-sm-6 col-md-3"> 
                     <label for="dateStart" >Start date</label>

                    <input id="dateStart" name="startDate" type="date" value="<?= (isset($_SESSION["frontPageSearch"]["startDate"]))? $_SESSION["frontPageSearch"]["startDate"]: date("Y-m-d") ?>"  class="form-control"  required >
                        </br>
                  </div>
                  <div class="col-12 col-sm-6 col-md-3">
                    <label for="dateStartTime">Start time</label>
                    <input id="dateStartTime" name="startDateTime" type="time" class="form-control" value="<?= (isset($_SESSION["frontPageSearch"]["startDateTime"]))? $_SESSION["frontPageSearch"]["startDateTime"]: date("H:i") ?>" required>

                    </br>
                  </div>
                  <div class="col-12 col-sm-6 col-md-3">  
                    <label for="dateEnd">End date</label>
                    <input id="dateEnd" name="endDate"  type="date" value="<?= (isset($_SESSION["frontPageSearch"]["startDate"]))? $_SESSION["frontPageSearch"]["endDate"]:date("Y-m-d") ?>"class="form-control"  required>
                    </br>
                  </div>
                   <div class="col-12 col-sm-6 col-md-3">
                    <label for="dateEndTime">End time</label>
                    <input id="dateEndTime" name="endDateTime"  type="time" class="form-control" value="<?= (isset($_SESSION["frontPageSearch"]["endDateTime"]))? $_SESSION["frontPageSearch"]["endDateTime"]:date("H:i") ?>" required>

                    </br>
                </div>
                 <hr class="col-12"> 
                </div>
                <div class="row">
                    
                    <div class="col-12 col-sm-6 col-md-2">
                         <label for="driverCheck">Need a driver?</label>
                    </div>
                    <div class="col-12 col-sm-6 col-md-2">
                         <input type="checkbox" id="driverCheck"  name="driverCheck" class="">
                    </div>
                     <div class="col-12 col-sm-6 col-md-2">
                         <label for="deliveryCheck">Want it to be delivered?</label>
                    </div>
                    <div class="col-12 col-sm-6 col-md-2">
                         <input type="checkbox" id="deliveryCheck" name="deliveryCheck" class="">
                    </div>
                    
                    <div class="col-12 col-sm-6 col-md-2">
                   <label for="advanced-search">Additional filters:</label>
                    </div>
                    <div class="col-12 col-sm-6 col-md-2">
                         <input type="checkbox" id="advanced-search" class="">
                    </div>
                 <hr class="col-12"> 

                </div>

               
                  <div class="row pickup-location-member" style="display:none">
                        <div class="col-12">
                           <h3 class="mb-3">Delivery location*</h3> 
                        </div>
                      
                        <div class="mb-3 col-12 col-sm-6 col-md-3">
                          <label for="address">Address</label>
                          <input type="text" class="form-control addressSelect" id="address" name="address" placeholder="1234 Eden street" >
                        </div>
                      
                        <div class="mb-3 col-12 col-sm-6 col-md-3">
                          <label for="address2">Address 2 <span class="text-muted">(Optional)</span></label>
                          <script src="../js/script.js" type="text/javascript"></script>
                          <input type="text" class="form-control" id="address2" name="address2" placeholder="Apartment or suite">
                        </div>


                        <div class="col-12 col-sm-6 col-md-3 mb-3">
                          <label for="county">county</label>
                          <select class="custom-select d-block w-100 addressSelect county" id="county" name="county"></select>
                        </div>
                      
                        <div class="col-12 col-sm-6 col-md-3 mb-3">
                          <label for="postcode">Postcode</label>
                          <input type="text" class="form-control addressSelect county" id="postcode" placeholder="K123 W123" name="postcode" >
                        </div>
                      
                       
                        

                  </div>   
                  <div class="row pickup-location-member"style="display:none">
                      
                         <div class="col-12 col-sm-6">
                              <label for="leaveVehicle">Want the vehicle leave at the pickup point at the end of the trip?</label>
                         </div>
                      
                         <div class="col-12 col-sm-6">
                              <input type="checkbox" id="leaveCheck" class="">
                         </div>
                      
                        <div class="badge-info col-12">
                          Vehicles are delivered to the specified location on the specified date and time.
                        </div>
                      
                     <hr class="col-12"> 

                             
                  </div>    
     
     
     
     
                <div class="row advanced-search-member">
                    <div class="col-12">
                         <h3> Bus specs </h3>
                    </div>
                </div>    
                <div class="row advanced-search-member">
                        <div class="col-12 col-sm-6 col-md-4 float-left">
                           
                            <label for="make">Make</label>
                            <select id="make" name="make" class="form-control"></select> 
                            </br>
                            </div>
                        <div class="col-12 col-sm-6 col-md-4 float-left">
                            <label for="model">Model</label>
                             <select id="model" name="model" class="form-control"></select>
                            </br>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4 float-left">
                            <label id="test" for="numberOfSeats">Number of seats required</label>
                            <input id="numberOfSeats"  name="numberOfSeats" type="number" value="" class="form-control">
                       </div>
                    
                </div>
                <div class="clearfix"></div>
                <div class="row advanced-search-member">
                    <div class="col-12 col-sm-6 col-md-4 col-12">
                         <h3>Cost & licnese</h3>
                    </div>
                </div>
                <div class="row advanced-search-member">
                    <div class="col-12 col-sm-6 col-md-4 float-left">

                        <label for="priceMin">Minimum Cost/hour</label>
                        <input id="priceMin" name="priceMin" type="number" class="form-control">
                         </br>
                    </div>
                    <div class="col-12 col-sm-6 col-md-4 float-left">

                        <label  for="priceMax">Maximum Cost/hour</label>
                        <input id="priceMax" name="priceMax" type="number" class="form-control">
                         </br>
                    </div>
                   <div class="col-12 col-sm-6 col-md-4 float-left">
                        <label for="licenseType">Driving Licence Required</label>
                          <select id="licenseType" name="licenseType" class="form-control"></select>
                          <br>
                   </div>

                </div>

                <button id="browseSearchButton" type="submit" class="btn btn-primary btn-lg btn-block"> Search offers</button>
                <div id="error"></div>
            </form>
        <?php if(isset($_SESSION["frontPageSearch"])): ?>
                <script type="text/javascript">
                <?php
               
                $options = "startDate=". $_SESSION["frontPageSearch"]["startDate"]
                        ."&startDateTime=".$_SESSION["frontPageSearch"]["startDateTime"]
                        ."&endDate=".$_SESSION["frontPageSearch"]["endDate"]."&endDateTime=".$_SESSION["frontPageSearch"]["endDateTime"];
                        
                ?>
                console.log("<?= $options ?>");    
              getVehicles("<?= $options?>");
                </script>
        <?php endif; ?>
        <div class="album py-5 bg-light">
            <div id="buses" class="container">


            </div>
        </div>
    

<?php
 require_once("footer.php");
 ?>
 