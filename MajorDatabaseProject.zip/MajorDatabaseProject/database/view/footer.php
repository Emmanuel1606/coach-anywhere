<?php
require_once("../controller/Config.php");
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

  if(isset ($_SESSION['loggedIn']))
  {
    header ('Location: admin.php');
    exit();
  }

  if (isset($_POST['login']))
  {
    $connection = new mysqli($host, $user, $password, $dbname);
    $email = $connection->real_escape_string($_POST['emailPhp']);
    $password = md5($connection->real_escape_string($_POST['passwordPhp']));
    $data = $connection->query("SELECT id FROM admin WHERE email= '$email' AND password= '$password'");
    if ($data->num_rows > 0)
    {
      $_SESSION['loggedIn'] = '1';
      $_SESSION['email'] = $email;
      exit(' Login successful. Welcome');
    }
    else{
      exit('Login Failed');
    }
    exit($email . " password is " . $password);
  }
?>
            <div class="modal fade" id="errorModal" tabindex="-1" role="dialog" aria-labelledby="errorModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="errorModalLabel">Modal title</h5>
                  </div>
                  <div class="modal-body" id="errorModalBody">

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">OK</button>
                  </div>
                </div>
              </div>
            </div>

  <!-- This is the modal for login page.-->
            <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h2 class="modal-title" id="exampleModalLabel">Login</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                  <div class="row">
                      <div class="col-md-6 login-form-1">
                          <form method= "post" action= "footer.php">
                              <div class="form-group">
                                  <h4>Enter Email</h4><input type="text" id= "emailLogin" class="form-control" placeholder="Your Email *" value="" />
                              </div>
                              <div class="form-group">
                                  <h4>Enter Password</h4><input type="password" id= "passwordLogin" class="form-control" placeholder="Your Password *" value="" />
                              </div>
                              <p id= "responseBox"></p>
                              <div class="form-group">
                              <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                Forgot Password?
                              </button>
                                  <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <div class="form-group">
                                        <h4>Enter Email</h4><input type="text" class="form-control form-control-sm" placeholder="Enter Your Email *" value="" />
                                        </div>
                                        <div class="form-group">
                                          <h4>Reset Password</h4><input type="password" class="form-control form-control-sm" placeholder="Type new Password *" value="" />
                                      </div>
                                      <div class="form-group">
                                          <h4>Confirm Password</h4><input type="password" class="form-control form-control-sm" placeholder="Confirm Password *" value="" />
                                      </div>
                                      <div class="form-group">
                                      <button type="button" class="btn btn-primary">Reset!</button>
                                      </div>
                                    </div>
                                  </div>
                              </div>
                          </form>
                      </div>
              </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id= "logIn" class="btn btn-primary">Login</button>
                    <script type = "text/javascript">
                      $(document).ready(function() {
                        $("#logIn").on('click', function() {
                          var email = $("#emailLogin").val();
                          var password = $("#passwordLogin").val();
                            if (email == "" || password == "")
                            {
                              alert ('No inputs recorded!');
                            }else {
                              $.ajax(
                              {
                                url: 'footer.php',
                                method: 'POST',
                                data:{
                                  login: 1,
                                  emailPhp:email,
                                  passwordPhp: password
                                },
                                success: function(response) {
                                  $("#responseBox").html(response);
                                  if(response.indexOf('success') >= 0)
                                  {
                                    window.location = 'admin.php';
                                  }
                                },
                                dataType: 'text'
                              }
                            ); 
                            }
                        });
                      });
                    </script>                    
                  </div>
                </div>
              </div>
            </div>

            <!-- This is the modal for signup page.-->
            <div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h2 class="modal-title" id="exampleModalLabel">Signup</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                  <div class="row">
                      <div class="col-md-6 login-form-2">
                          <form>
                              <div class="form-group">
                                  <h4>Enter Email</h4><input type="text" class="form-control" placeholder="Your Email *" value="" />
                              </div>
                              <div class="form-group">
                                  <h4>Create Password</h4><input type="password" class="form-control" placeholder="Your Password *" value="" />
                              </div>
                              <div class="form-group">
                                  <h4>Repeat Password</h4><input type="password" class="form-control" placeholder="Your Password *" value="" />
                              </div>
                          </form>
                      </div>
              </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Signup</button>
                  </div>
                </div>
              </div>
            </div>
                <footer>
 			<p>Coach Anywhere, Copyright &copy; 2019</p>
 		</footer>
    </div>   
 	</body>
 </html>