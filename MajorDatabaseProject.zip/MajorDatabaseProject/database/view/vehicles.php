<<<<<<< HEAD
<!DOCTYPE html>
 <html>

 	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width">
 		<meta name="description" content="Coach booking">
 		<meta name="keywords" content="vehicles, prices, contact">
 		<meta name="author" content="Emmanuel Pereira">
 		<title>Coach Anywhere</title>
 		<link rel="stylesheet" href="../css/style.css">
 	</head>


 	<body>
 		<header>
			<div class="container">
 				<div id="branding">
 					<h1>Vehicles</h1>
 				</div>
 				<nav>
 					<ul>
 						<li><a href="index.php">Home</a></li>
 						<li><a href="vehicles.php">Vehicles</a></li>
 						<li class="current"><a href="contact.php">Contact</a></li>
						<li><a href="login.php">Login</a></li>
 					</ul>
 				</nav>
 			</div>
 		</header>
=======
<?php require_once("header.php"); ?>
>>>>>>> d0361e4859dbf46b3f80451c4548ee7389f4dd54


 		<section id="newsletter">
 			<div class="container">
 				<h1>Subscribe for Latest Notifications</h1>
 				<form>
 					<input type="email" placeholder="Enter Email">
 					<button type="submit" class="button1">Subscribe</button>
 				</form>
 			</div>
 		</section>


 		<section id="main">
 			<div class="container">
 				<article id="main-col">
 					<h1 class="page-title">Vehicles</h1>
 					<ul id="vehicles">
 						<li>
 							<h3>Upcoming Vehicles!</h3>
 							<p>Mercedes Tourismo</p>
 							<p>The new mercedes tourismo is expected to release later this month. With the option to choose the colour and chasis which best suits you. A perfect balance of safety and comfort, the stylish coach is economically-efficient, while providing reliability and peace of mind for any driver. <br>
 							The production of this coach started apporximately near the end of last year, so the expected release date would be somewhere along mid-march,.
 							</p>
 						</li>
 						<li>
 							<h3>Release </h3>
 							<p>Production: End of 2018 <br> Release Date: 15 March 2019
 							</p>
 							<p></p>
 						</li>
 						<li>
 							<h3>More Vehicles</h3>
 							<p>There are a range of other vehicles to choose from, which means that we are sure you will find one best suited to your needs. Whether you need a minibus, touring coach or a coach with special specifications, we got the one for you, with a range of selections to choose from. These ranges include:<br><br>Scania Tour (Touring)<br>Van Hool (Luxury)<br>Temsa (Mini)<br>AstroMega (Large capacity)<br>Volvo 9900 (Performance)</p>
 							<p></p>
 						</li>
 					</ul>
 				</article>


 				<aside id="sidebar">
 					<div class="dark">
 						<h3>More Info</h3>
 						<form class="info">
 								<div>
 									<label>Name</label><br>
 									<input type="text" placeholder="Name">
 								</div>
 								<div>
 									<label>Email</label><br>
 									<input type="text" placeholder="Email Address">
 								</div>
 								<div>
 									<label>Message</label><br>
 									<textarea placeholder="Message"></textarea>
 								</div>
 								<button class="button1" type="submit">Send</button>
 						</form>	
 					</div>
 				</aside>		
 			</div>
 		</section>
<?php require_once("footer.php"); ?>
