<?php
require_once("header.php");
//This is not ok, as what if the user comes here to check a previous order while having new things in the basket???
$_SESSION["Basket"] = new Basket();
        

if(isset($_SESSION["lastInsertHash"]) || isset($_REQUEST["hash"]))
    {
    if(isset($_REQUEST["hash"]))
        {
        $hash =$_REQUEST["hash"];
        }
    else if(isset($_SESSION["lastInsertHash"]))
        {
        $hash =$_SESSION["lastInsertHash"];
        }
?>
<script type="text/javascript">
    //alert("<?= $hash ?>");
    getCustomerOrders("<?= $hash ?>");
</script>    
    <div class="row">
            <div class="col-12">

            <h2>Your order has been processed!</h2>
           <h2>See your order details below:</h2>

            </div>
    </div>
    <div id="orderResults">
        
    </div>    <!-- end orderResults -->
       
        <!-- end orderdetails -->
   

<?php  
require_once("footer.php");
} else {
//     //does redirection work with relative paths???
header('Location: ./index.php');
    
exit(0);
}
?>