<?php
require_once("adminHeader.php");
?>
<!doctype html>
<html>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script type="text/javascript" src="../js/adminjs.js"></script>


<body>
<button id= "addVehicles">Add Vehicles</button>

            <div id="adminB">

            </div>
</body>
</html>