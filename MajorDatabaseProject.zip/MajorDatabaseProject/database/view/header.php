<?php 
require_once("../model/Basket.php");
require_once("../model/BasketItem.php");

session_start();

if(!isset($_SESSION['Basket'])) $_SESSION['Basket'] = new Basket();
?>
<!DOCTYPE html>
 <html>
 	<head>
		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width">
 		<meta name="description" content="Coach booking">
 		<meta name="keywords" content="vehicles, prices, contact">
 		<meta name="author" content="Emmanuel Pereira">
 		<title>Coach Anywhere</title>
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 		<link rel="stylesheet" href="../css/style.css">
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script  src="https://code.jquery.com/ui/1.12.0/jquery-ui.min.js"  integrity="sha256-eGE6blurk5sHj+rmkfsGYeKyZx3M4bG+ZlFyA7Kns7E="   crossorigin="anonymous"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.js"></script>
                <script src="../js/script.js"></script>

 	</head>


 	<body>
        <div class="container-fluid">
            <nav class="navbar navbar-dark bg-dark navbar-expand-lg" id="mainMenu">
                <a class="navbar-brand" href="./">Berwyn Busess</a>
                <button id = "menuButton" 
                        class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon text-light" ><img id="mobile-menu-icon" src="../images/menu-icon.png" ></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                  <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                      <a class="nav-link" href="../view/index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="../view/vehicleBrowserForm.php">Vehicles</a></li>
                    </li>
                    <li class="nav-item">
                     <a class="nav-link" href="../view/contact.php">Contact</a></li>
                    </li>
                    
                     <li class="nav-item mr-1">
                                     <a class="nav-link" href="./Cart.php"><span class="text-muted mr-3">Basket</span><span id="basketBadge" class="badge badge-secondary badge-pill">0</span></a>      
                    </li>
                    <li class="nav-item mr-1">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#login">Login</button>
                    </li>
                    <li class="nav-item mr-1">
                         <button type="button" class="btn btn-success" data-toggle="modal" data-target="#signup">Signup</button>
                     </li>
                  </ul>
                </div>
              </nav>


 			


