<?php require_once("header.php"); ?>
                <section id="showcase">
  			<div class="container">
  				<h1>Hire a coach for any occasion!</h1>
  			</div>
  		</section>
 				<form action="./vehicleBrowseForm.php" id="homePageSearch" validate>
                                 <div class="row text-white bg-dark mx-1 p-5">
                                   
                                      <div class="col-12 col-sm-6 col-md-4 col-lg-3"> 
                                        <label for="dateStart" >Start date</label>

                                       <input id="dateStart" name="startDate" type="date" value="<?= (isset($_SESSION["frontPageSearch"]["startDate"]))? $_SESSION["frontPageSearch"]["startDate"]: date("Y-m-d") ?>"  class="form-control"  required >
                                           </br>
                                     </div>
                                     <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                                       <label for="dateStartTime">Start time</label>
                                       <input id="dateStartTime" name="startDateTime" type="time" class="form-control" value="<?= (isset($_SESSION["frontPageSearch"]["startDateTime"]))? $_SESSION["frontPageSearch"]["startDateTime"]: date("H:i") ?>" required>

                                       </br>
                                     </div>
                                     <div class="col-12 col-sm-6 col-md-4 col-lg-3">  
                                       <label for="dateEnd">End date</label>
                                       <input id="dateEnd" name="endDate"  type="date" value="<?= (isset($_SESSION["frontPageSearch"]["startDate"]))? $_SESSION["frontPageSearch"]["endDate"]:date("Y-m-d") ?>"class="form-control"  required>
                                       </br>
                                     </div>
                                     <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                                       <label for="dateEndTime">End time</label>
                                       <input id="dateEndTime" name="endDateTime"  type="time" class="form-control" value="<?= (isset($_SESSION["frontPageSearch"]["endDateTime"]))? $_SESSION["frontPageSearch"]["endDateTime"]:date("H:i") ?>" required>

                                       </br>
                                   </div>
                                 </div>  
        
                                <div class="row">
                                  <div class="col-12">
                                      
                                      <button type="submit" class="form-control btn-primary btn-lg" id="" >Book a vehicle</button>
                                  </div> 
                                </div>
                                    
 				</form>
 			</div>


 		<script type="text/javascript">
 			function myFunction() {
 				location.replace("vehicles.php");
 			}
 		</script>
		 
	<div class="container text-left mt-5">
    <h1 class="display-4">Promotions!</h1>
  </div>
<div class="container text-center text-dark mt-5 mb-5" id="promo">
  <section class="row">
    <article class="col-4" >
    <div class="card" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/fordtransit.jpg" class="card-img-top" alt="Vehicle Image">
        <div class="card-body">
          <h5 class="card-title">All new Ford!</h5>
            <p class="card-text">Get 25% off the hourly rate for this new Ford minibus when you purchase within the next few days.</p>
              <a href="vehicleBrowserForm.php" class="btn btn-dark">Find out more!</a>
        </div>
    </div>  
    </article>

    <article class="col-4" >
    <div class="card" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/vanhoolastromega.jpg" class="card-img-top" alt="Vehicle Image">
        <div class="card-body">
          <h5 class="card-title">Travel the globe in style!</h5>
            <p class="card-text">The luxourious astromega is bound to provide maximum comfort with the latest entertainment system.</p>
              <a href="vehicleBrowserForm.php" class="btn btn-dark">Find out more!</a>
        </div>
    </div>  
    </article>

    <article class="col-4" >
    <div class="card" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/mercedessprinter.jpg" class="card-img-top" alt="Vehicle Image">
        <div class="card-body">
          <h5 class="card-title">Want a vehicle ASAP!</h5>
            <p class="card-text">Our mercedes sprinter is available for next day when you purchase anytime this week.</p>
              <a href="vehicleBrowserForm.php" class="btn btn-dark">Find out more!</a>
        </div>
    </div>  
    </article>
  </section>
 </div>

    <div class="container text-center text-dark mt-5 mb-5" id="secondpromo">
  <section class="row">
    <article class="col-4" >
    <div class="card" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/vanhoolastron.jpeg" class="card-img-top" alt="Vehicle Image">
        <div class="card-body">
          <h5 class="card-title">Most economically efficient!</h5>
            <p class="card-text">If your looking for something more fuel efficient, look no further than the Vanhool Astron.</p>
              <a href="vehicleBrowserForm.php" class="btn btn-dark">Find out more!</a>
        </div>
    </div>  
    </article>

    <article class="col-4" >
    <div class="card" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/fordtourneo.PNG" class="card-img-top" alt="Vehicle Image">
        <div class="card-body">
          <h5 class="card-title">A little more vibrant!</h5>
            <p class="card-text">The Ford tourneo comes in a lovely orange chrome, with the new mode consisting of the latest tech.</p>
              <a href="vehicleBrowserForm.php" class="btn btn-dark">Find out more!</a>
        </div>
    </div>  
    </article>

    <article class="col-4" >
    <div class="card" style="width: 18rem; height: 28rem;">
      <img src="../images/vehicles/scaniairizar.jpg" class="card-img-top" alt="Vehicle Image">
        <div class="card-body">
          <h5 class="card-title">Comfort at it's best!</h5>
            <p class="card-text">No matter how long the journey, the new Irizar i8 is sure to give you a mesmerising experience.</p>
              <a href="vehicleBrowserForm.php" class="btn btn-dark">Find out more!</a>
        </div>
    </div>  
    </article>
  </section>
 </div> 

<?php require_once("footer.php"); ?>

 
