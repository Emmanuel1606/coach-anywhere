<!doctype html>
<html>
<head>
<title> </title>
<link rel="stylesheet" href="./css/" type="text/css">
</head>
<body>
<div id="mainContainer">

</div>
<script type="text/javascript" src="./js"></script>
</body>
</html>