function updateSelectOptions(type, objects)
{   
    var fieldDefault ="Any";
    //this doesn't work!!!
    console.log(objects);
    if(objects.length==0)
    {
        fieldDefault = "No results for "
        
    } 
    var selector ="#";
     if(type=="county"){
         selector = ".";
     } 
    $(selector+type).empty().append('<option value="0">Any '+type+'</option>');   
    for(var i = 0; i<objects.length; i++)
    {
        
      
     $(selector+type).append('<option value="'+objects[i].ID+'">'+objects[i][type+"Name"]+'</option>');   
    }
    
}
function getFormField(optionType, additionalQuery)
{
    
    var queryBuild = (additionalQuery.length>0)?"&query=true"+additionalQuery:"";
    console.log('type='+optionType+queryBuild);
    $.ajax({
        type: "GET",
        url: "../controller/RequestHandler.php",
        data: 'type='+optionType+queryBuild,
        dataType: 'json',
        success: function(result)
    {
        console.log(result);
        updateSelectOptions(optionType, result);
        
        
    }
        
    });
};


function modalShow(title, message)
{
    $('#errorModal #errorModalLabel').text(title);
     $('#errorModal #errorModalBody').text(message);
    $('#errorModal').modal('show');
    
}

function updateBasket(id)
{
    //send add request to SessionHandler
    //session handler either says ok or says not ok
    //depending on that you show the error message!
    
    
    var idComponents = id.split("_");
    var dataToPass = 
    {
        command: "add",
        busID: id,
        busModel :  $("#model_"+idComponents[1]).text(),
        busMake : $("#make_"+idComponents[1]).text(),
        ratePerHour:  $("#ratePerHour_"+idComponents[1]).text(),
        colour:  $("#colour_"+idComponents[1]).text(),
        numberOfSeats:  $("#numberOfSeats_"+idComponents[1]).text(),
        startDateTime: new Date($("#dateStart").val()+"T"+$("#dateStartTime").val()).getTime(),
        endDateTime: new Date($("#dateEnd").val()+"T"+$("#dateEndTime").val()).getTime(),
        driverCheck: $("#driverCheck").prop("checked"),
        deliveryCheck: $("#deliveryCheck").prop("checked"),
        address: {
         addressLine1: $("#address").val(),
         addressLine2:$("#address2").val(),
         county:$("#county").val(),
         postcode:$("#postcode").val()
        },
        leaveCheck:  $("#leaveCheck").prop("checked")
    }
    console.log(dataToPass); 
    if(!dateCheck()) return;
        $.ajax(
                {
                    method:"post",
                    url: "../controller/SessionHandler.php",
                    data: dataToPass,
                    success: function (data)
                    {
                        console.log(data);
                        var messageComponents = data.split("-");
                        modalShow(messageComponents[0], messageComponents[1]);
                        //check what has happened? success? Not success?
                        if(messageComponents[0]=="Succes") updateBasketBadge();
                    }
                    
                });

}

function dateCheck()
{
       var today = new Date().getTime();
       var startDateTime = new Date($("#dateStart").val()+"T"+$("#dateStartTime").val()).getTime();
       var endDateTime = new Date($("#dateEnd").val()+"T"+$("#dateEndTime").val()).getTime();
       if(startDateTime<=today)
       {
           modalShow("Wrong specified date", "The specified start date has to be later than the current date and time.");
           return false;
       }
 

        if(startDateTime>=endDateTime)
       {
           modalShow("Wrong specified date", "The specified end date is not later than the start date of the booking.");
           return false;
       }
       return true;
    
}  
function updateBasketBadge()
{   
        $.ajax(
                {
                    method:"post",
                    url: "../controller/SessionHandler.php",
                    data: "command=itemNumber",
                    success: function (data)
                    {
                        
                        $("#basketBadge").text(data);
                    }
                    
                });

}

function getVehicles(query)
{
    
    var  queryBase = "type=vehicle&html=true";
    var fullQuery =(query!=undefined)? queryBase+"&query=true&"+query : queryBase;
    console.log(" fullQuery"+ fullQuery);
    $.ajax({
     type: "GET",
     url: "../controller/RequestHandler.php",
     data: fullQuery,
     dataType:"html",
     success: function(result)
     {
      console.log("HTML for vehicles has been returned");
           $('#buses').empty();
            $('#buses').append(result);
              $('.addToBasket').click(
              function()
                {
                    console.log("I have been clicked");
                    console.log("Bus id:"+$(this).attr('id'));
                    updateBasket($(this).attr('id'));

                });

     },
     error: function(e){
         console.log("Error:"+e);
     }
       
    });
    
}

function removeItemFromBasket()
{
    var fullID =($(this).attr("id"));
    
    var idComps = fullID.split("_");
    console.log(fullID);
    $.ajax({
            url: "../controller/SessionHandler.php",
            method: "post",
            data: {
                command:"remove",
                removeID: idComps[1]
             },
             success: function(result)
             {
                 resultComponents = result.split("-");
                 if(resultComponents[0]=="Success"){
                     var currentBasketTotal = parseInt($("#basketTotal").text());
                     console.log("currentBasketTotal"+currentBasketTotal);
                     var updatedValue = currentBasketTotal - parseInt($("#busTotal_"+idComps[1]).text());
                     $("#basketTotal").text(updatedValue);
                     $("#basketItem_"+idComps[1]).remove();
                 }
                 modalShow(resultComponents[0], resultComponents[1]);
                 updateBasketBadge(); 

             }
       
    });
}
function getCustomerOrders(hash)
{
    console.log("Hash has been sent: "+hash);

    $.ajax(
            {
             method: "post",
             data: "type=viewOrders&hash="+hash,
             url: "../controller/RequestHandler.php",
             dataType: "json",
             success: function(response)
             {
                 console.log(response);
                 var paymentName;
                 if(response.paymentMethod==0){
                     paymentName="Credit Card";
                 } else if (response.paymentMethod==2){
                     paymentName="Debit Card";
                 } else {
                    paymentName="Paypal";
                 }
            var output =`
            
            <div class="row mb-4 p-2">

                 <div class="col-12 col-md-6 col-lg-3 mt-3">

                  <h4 class="mb-3">Contact details</h4>

                      <div class="">
                        <span class="badge badge-primary">First name</span>
                        <span for="firstName">`+response.firstName+`</span>
                      </div>  

                      <div class="">
                        <span class="badge badge-primary">Last name</span>
                        <span>`+response.lastName+`</span>                     
                      </div>
              

                    <div class="mb-3">
                      <span class="badge badge-primary">Email</span>
                      <span>`+response.emailAddress+`</span>                     

                    </div>
                  <div class="mb-3">
                      <span class="badge badge-primary">Telephone</span>
                      <span>`+response.phoneNumber+`</span>                     

                    </div>
                </div>

                 
            <div class="col-12 col-md-6 col-lg-3 mt-3">
                  <h4 class="mb-3">Billing address</h4>

                    <div class="mb-3">
                       <span class="badge badge-primary">Address</span>
                        <span>`+response.address+`</span>                    
                    </div>

                    <div class="mb-3">
                      <span class="badge badge-primary">Address 2</span>
                      <span>`+response.address2+`</span>        
                    </div>

                    <div class="mb-3">
                       <span class="badge badge-primary">county</span>
                       <span>`+response.countyName+`</span>  

                    </div>
                    <div class="mb-3">
                      <span class="badge badge-primary">Postcode</span>
                      <span>`+response.postcode+`</span>                     
                    </div>


            </div>
            <div class="col-12 col-md-6 col-lg-3" >
                        <div id="shippingAddressDetails">`;
             if(response.shippingSelector!=null){
             output+=`
                            <div class="mb-3">
                               <h4 class="mb-3">Shipping address</h4>
                               <span class="badge badge-primary">Address</span>
                               <span class="">`+response.saddress1+`</span> 
                            </div>

                            <div class="mb-3">

                               <span class="badge badge-primary">Address 2</span>
                                <span class="">`+response.saddress2+`</span> 
                            </div>


                                 <span class="badge badge-primary">County</span>
                                <span class="">`+response.scountyName+`</span>

                                 <span class="badge badge-primary">Postcode</span>
                                 <span class="]">`+response.spostcode+`</span>

                            </div>
             </div>`  
             };  
             output+=`<div class="col-12 col-md-6 col-lg-3 mt-3">
                        <h4 class="mb-3">Payment mode</h4>

                        <span class="badge badge-primary">Payment</span>
                        <span class="">`+paymentName+`</span>`;
             if(response.bname!=null){
                 
             output +=`
                        <h4 class="mb-3">Business name</h4>
                        <span class="badge badge-primary">Business name</span>
                             <span>`+response.bname+`</span>`;
               }
               output+=`
                    </div>
                    </div>
               </div>
                 
                <div class="row">    
                           <div class="col-12 m-1 px-4 table-responsive">
                               <table class="table table-hover table-dark">
                                 <thead>
                                   <tr>
                                     <th scope="col">ID</th>
                                     <th scope="col">busModel</th>
                                     <th scope="col">Start date</th>
                                     <th scope="col">End date</th>
                                     <th scope="col">Delivery Location</th>
                                     <th scope="col">Vehicle pickup</th>
                                     <th scope="col">Driver</th>

                                   </tr>
                                 </thead>
                                 <tbody>`;
                 for(var i = 0; i<response.Bookings.length; i++)
                 {
                     
                     var deliveryAddress = response.Bookings[i].line1+" "+response.Bookings[i].line2+" "+response.Bookings[i].postCode;
                         deliveryAddress = (deliveryAddress == "  ")? "Not specified" : deliveryAddress;   
                     var deliveryCheck = (response.Bookings[i].deliveryCheck=="1")?"yes":"no";
                     var driverCheck = (response.Bookings[i].driverRequired=="1")?"yes":"no";
                     output+=`
                       <tr>
                      <th scope="row">`+(i+1)+`</th>
                      <td>`+response.Bookings[i].modelName+`</td>
                      <td>`+response.Bookings[i].startDateRequired+`</td>
                      <td>`+response.Bookings[i].EndDateRequired+`</td>
                      <td>`+deliveryAddress+`</td>
                      <td>`+deliveryCheck+`</td>
                      <td>`+driverCheck+`</td>
                        </tr>`;
                 }
                output+=`
                  </tbody>
                </table>
            </div>
        </div>`;
            $("#orderResults").empty();     
            $("#orderResults").append(output);     
             },
    
             error: function(jqXHR, textStatus, errorThrown){
                console.log(textStatus);
                console.log(errorThrown);
            }     
            })
    
}

function checkoutFormSubmit()
{
        var formData = $("#checkout-form").serialize()+"&"+$("#checkout-form2").serialize();
        console.log(formData);
        $.ajax({
            url : "../controller/RequestHandler.php",
            data: formData+"&type=processOrder",
            dataType: "html",
            success: function(response)
            {
               console.log(response);
               
                if(response.search("Success")>-1){
                  $("#step-2").hide();
                 $("#step-3").show();
                    window.setTimeout(function()
                    {
                     window.location.href="./OrderProcessed.php";

                    }, 4000); 
                    
                }
             
            }
        });
    
    
}
$(document).ready(function(){
    
    $(".removeBasketItem").click(removeItemFromBasket); 
    
    //these will have to be specialised!!!! These functions shouldn't be run on every page!!!
    
    getFormField("make", '');
    getFormField("model", '');
    getFormField("licenseType", '');
    getFormField("county", '');
    updateBasketBadge();      
    $('#deliveryCheck').change(function()
    {
        if($(this).prop("checked")==true)
        {
          $(".pickup-location-member").show();
          $(".addressSelect").prop("required", true);
  
        } else {
         $(".pickup-location-member").hide();
         $(".addressSelect").prop("required", false);


        } 
    });
    $('#advanced-search').change(function()
    {
        
        if($(this).prop("checked")==true)
        {
          $(".advanced-search-member").show();
  
        } else {
         $(".advanced-search-member").hide();

        }
        
        
    });
    
    $('#browseSearchButton').click(function(e)
    {
       e.preventDefault();
       if(dateCheck()){
        var options = ( $('#browseVehicle').serialize());
        console.log("options: "+options);
            $.ajax(
                        {
                            method:"post",
                            url: "../controller/SessionHandler.php",
                            data: { 
                                command: "frontPageSearch",
                                startDate: $("#dateStart").val(),
                                startDateTime: $("#dateStartTime").val(),
                                endDate: $("#dateEnd").val(),
                                endDateTime: $("#dateEndTime").val()
                            },
                            success: function(response)
                            {
                                
                                var responseCompnents = response.split("-");
                                if(responseCompnents[0]=="Success"){
                                   getVehicles(options); 

                                }else {
                                    console.log(response);
                                }
                            }
                        }
                    );
        
        
    }
    });
    
    $("#homePageSearch").submit(function(e)
    {
        e.preventDefault();
        if(dateCheck()){
          $.ajax(
                    {
                    method:"post",
                    url: "../controller/SessionHandler.php",
                    data: {
                        command: "frontPageSearch",
                        startDate: $("#dateStart").val(),
                        startDateTime: $("#dateStartTime").val(),
                        endDate: $("#dateEnd").val(),
                        endDateTime: $("#dateEndTime").val()
                    },
                    success: function(response)
                    {
                        var responseCompnents = response.split("-");
                        if(responseCompnents[0]=="Success"){
                        window.location.href="./vehicleBrowserForm.php";    
                        }else {
                            //
                         console.log(response);
  
                        }
                        
                    }
                        
                    }
                );
        }
    });
    $("#paypal").change(function(){
       alert("you should finish it later on"); 
    });
    $('#make').change(
        function()
        {
        var query = "";
       if($(this).children("option:selected").val()!=0)
       {
           query = '&makeID='+ $(this).children("option:selected").val();  
       }
        getFormField('model', query);
        });
    //functions used for the checkout from 
    $(".privateBusinessSelector").click(function()
    {
       $(".privateBusinessSelector").removeClass("active");
       $(this).addClass("active");
       if($(this).attr("id") == "privateTab") 
       {
           $("#businessCustomerForm").hide();
           $("#bname").prop("required", false);
           
       } else {
           $("#businessCustomerForm").show();
           $("#bname").prop("required", true);

       }


    });
  

    $("#same-address").change(function()
    {
        if($(this).prop("checked")) {
            $("#shippingAddressDetails").show();
            $(".switch_required").prop("required", true);
        } else {
           $("#shippingAddressDetails").hide();
           $(".switch_required").prop("required", false);
        }
    });
  
    $("#checkout-0-button").click(function(e)
    {
        e.preventDefault();
        $("#step-0").hide();
        $("#step-1").show();
        
        
    });
    
      $('#checkout-form').validate({ // initialize the plugin
        rules: {
            firstName: {
                required: true,
                minlength: 5
            },
            lastName: {
                required: true,
                minlength: 5
            },
            phoneNumber: {
                required: true,
                minlength: 9,
                number:true

            },
            emailAddress: {
                required: true,
                email: true
            },
            address: {
                required: true,
                minlength: 9
            },
            address2: {
                required: false,
                minlength: 9
            },
//            county: {
//                required: true,
//                minlength: 9
//            },
            Postcode: {
                required: true,
                minlength: 7
            },
        
            
        },
        submitHandler: function (form) { // for demo
              $("#step-1").hide();
              $("#step-2").show();
        }
    });
    
    $('#checkout-form2').validate({ // initialize the plugin
        rules: {
          
            paymentMethod: {
                required: true,
             
            },
            cc_name: {
                required: true,
                minlength: 9
            },
            cc_number: {
                required: true,
                minlength: 16,
                maxlength: 16,
                number: true
            },
            cc_expiration: {
                required: true,
                minlength: 7,
                date: true,
                
            },
             cc_cvv: {
                required: true,
                minlength: 3,
                maxlength: 4,
                number: true
            },
            
            
        },
        submitHandler: function (form) { // for demo
           
                checkoutFormSubmit();
                //window.location.href="./OrderProcessed.php";
       
            
        }
    });
    

    
     $("#checkout-1-button-back").click(function(e)
    {
        e.preventDefault();
        $("#step-1").show();
        $("#step-2").hide();

    });


});


                    
        
        
