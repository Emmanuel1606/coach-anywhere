function getadminVehicleList()
{
    var  queryBase = "type=vehicle";
    $.ajax({
     type: "GET",
     url: "../controller/RequestHandler.php",
     data: queryBase,
     dataType:"json",
     success: function(response)
     {
      console.log(response);
           var output="";
           output+= 
                   `<table>
                   <thead>
                   <tbody>
                       <tr>
                           <th scope="col">Make</th>
                           <th scope="col">Seats</th>
                           <th scope="col">Colour</th>
                           <th scope="col">£/h</th>
                           <th scope="col">Transmission Type</th>
                       </tr>`;
                       
				 for(var i =0; i<response.length; i++)
				{
                       output+=`<tr>
                   <td scope="col">`+response[i].makeName+`</td>
                   <td scope="col">`+response[i].numberOfSeats+`</td>
                   <td scope="col">`+response[i].colour+`</td>
                   <td scope="col">`+response[i].ratePerHour+`</td>
                   <td scope="col">`+response[i].transmissionType+`</td>
                   <td><button class= "edit" data-vehicle-id="`+response[i].ID+`">Edit</button></td>
                   <td><button class= "delete" data-vehicle-id="`+response[i].ID+`">Delete</button></td>

               </tr>`;
               
                    
                console.log(output);
                
				}
            $('#adminB').append(output);


            $(document).ready(function() {
                $("#addVehicles").click(
                    function()
                    {
                    location.href = "adminVehicleForm.php";
                });
            });

            $(".edit").click(
                function()
                {
                    alert("The id of this button is "+$(this).attr('data-vehicle-id'));
                }
            );
        
            $(".delete").click(
                function()
                {
                    alert("The id of this button is "+$(this).attr('data-vehicle-id'));
                }
            );

     },
     error: function(e){
         console.log("Error:"+e);
     }
       
    })
}
//"Mercedes-Benz", 53, "Green", "160", "D"
getadminVehicleList();
