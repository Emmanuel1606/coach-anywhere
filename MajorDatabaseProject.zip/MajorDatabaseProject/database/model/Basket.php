<?php

class Basket implements JsonSerializable{

    public $items;
    public $user;
    
    public function Basket(){
        $this->items = array();
        $this->user= "Guest";
    }
     public function jsonSerialize()
     {
        return get_object_vars($this);
     }
      public function &__get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }        



}