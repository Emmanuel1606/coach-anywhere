<?php
class Vehicle implements JsonSerializable
{
    
    private $ID;
    private $registrationNumber;
    private $dateOfRegistration;
    private $colour;
    private $modelID;
    private $modelName;
    private $numberOfSeats;
    private $transmissionType;
    private $makeID;
    private $makeName;
    private $hourlyRateID;
    private $ratePerHour;
    private $licenseTypeID;
    private $licenseTypeName;
    private $img;
    
       public function jsonSerialize()
       {
        return get_object_vars($this);
       }
      public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }       
    
}