<?php

class User  implements JsonSerializable
{
    private $firstName, $lastName, $emailAddress, $address;
    private $address2, $county, $countyName, $postcode, $paymentMethod;
    private $cc_name, $cc_number, $cc_expiration, $cc_cvv;
    private $shippingSelector, $saddress1, $saddress2;
    private $scounty, $spostcode, $bname;
    public function User()
            {
            $this->Bookings = [];
        
            }
    public function jsonSerialize()
            {
        return get_object_Vars($this);
            }
      public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }        

}