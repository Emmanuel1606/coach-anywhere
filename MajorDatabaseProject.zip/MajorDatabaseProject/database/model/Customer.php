<?php
class Customer  implements JsonSerializable
{
    private $name;
    private $userName;
    
}