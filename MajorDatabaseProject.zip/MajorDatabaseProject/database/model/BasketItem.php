<?php


class BasketItem implements JsonSerializable{
    public static $counter = 0;

    
    private $ID, $busID, $busModel, $busMake, $ratePerHour, $colour, $startDateTime, $endDateTime, $licenseTypeName, $numberOfSeats, 
            $driverCheck, $deliveryCheck, $address, $leaveCheck;
  
     public function BasketItem
    ($ID, $busID, $busModel, $busMake, $ratePerHour, $colour, 
             $startDateTime, $endDateTime,  $numberOfSeats, 
             $driverCheck, $deliveryCheck,$address, $leaveCheck )
    {
        $this->ID = $ID;
        $this->busID = $busID;
        $this->busModel = $busModel;
        $this->busMake = $busMake;
        $this->ratePerHour = $ratePerHour;
        $this->colour = $colour;
        $this->startDateTime = $startDateTime;
        $this->endDateTime = $endDateTime;
        $this->numberOfSeats = $numberOfSeats;
        $this->driverCheck = $driverCheck;
        if($deliveryCheck==true){
        $this->deliveryCheck = $deliveryCheck;
        $this->address = $address;
        $this->leaveCheck = $leaveCheck;
        } else {
        $this->deliveryCheck = null;
        $this->address = null;
        $this->leaveCheck = null;   
        }

}   
   
     public function jsonSerialize()
     {
        return get_object_vars($this);
     }
      public function &__get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }     
}