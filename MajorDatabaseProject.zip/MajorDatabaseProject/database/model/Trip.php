<?php
class Trip  implements JsonSerializable
{
    private $tripID;
    private $customer;
    private $tripDate;
    
     public function jsonSerialize()
            {
        return get_object_Vars($this);
            }
      public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }        
    
}