<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of licenseType
 *
 * @author Regory Gregory
 */
class licenseType  implements JsonSerializable{
   public $ID;
   public $licenseTypeName;
   
    public function jsonSerialize()
            {
        return get_object_Vars($this);
            }
      public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }        

}
?>