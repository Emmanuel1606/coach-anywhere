<?php
class Make  implements JsonSerializable{
    public $id;
    public $name;  
    
     public function jsonSerialize()
            {
        return get_object_Vars($this);
            }
      public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }        
    
}


?>