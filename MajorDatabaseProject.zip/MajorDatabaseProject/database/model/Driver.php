<?php
class Driver  implements JsonSerializable
{
    private $surname;
    private $lastname;
    private $licenceID;
    private $licenceExpiry;
    private $profilePhoto;
    private $bio;
     public function jsonSerialize()
            {
        return get_object_Vars($this);
            }
      public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;

    }        
   
    
}